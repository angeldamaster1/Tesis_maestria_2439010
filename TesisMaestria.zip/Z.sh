pdflatex main.tex
biber main
pdflatex main.tex
pdflatex main.tex
evince main.pdf

